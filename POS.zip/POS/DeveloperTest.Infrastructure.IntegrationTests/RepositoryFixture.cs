﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using DeveloperTest.Infrastructure.Data;

using Microsoft.EntityFrameworkCore;

namespace DeveloperTest.Infrastructure.IntegrationTests
{
    public class RepositoryFixture
    {
        public RepositoryFixture()
        {
            var connectionString = Helpers.GetConfig()["ConnectionStrings:DeveloperTestDB"];

            var optionsBuilder = new DbContextOptionsBuilder<DeveloperTestContext>();
            optionsBuilder.UseSqlServer(connectionString);

            DeveloperTestContext = new DeveloperTestContext(optionsBuilder.Options);
            DeveloperTestContext.Database.EnsureCreated();
            CancellationTokenSource = new CancellationTokenSource();
        }

        public DeveloperTestContext DeveloperTestContext { get;}
        public CancellationTokenSource CancellationTokenSource { get; }
    }
}
