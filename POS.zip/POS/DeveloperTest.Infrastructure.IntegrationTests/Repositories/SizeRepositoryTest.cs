﻿using System.Threading.Tasks;
using DeveloperTest.Infrastructure.Respositories;
using Xunit;

namespace DeveloperTest.Infrastructure.IntegrationTests.Repositories
{
    public class SizeRepositoryTest : IClassFixture<RepositoryFixture>
    {
        private readonly RepositoryFixture _fixture;

        public SizeRepositoryTest(RepositoryFixture fixture)
        {
            _fixture = fixture;
        }

        [Fact]
        public async Task GetSize_Successfully()
        {
            const int expectedResult = 7;
            var sizeRepository = new SizeRepository(_fixture.DeveloperTestContext);
            var result = await sizeRepository.GetSizes(_fixture.CancellationTokenSource.Token);
            Assert.NotNull(result);
            Assert.Equal(expectedResult,result.Count);
        }
    }
}