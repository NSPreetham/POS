﻿using System.Threading.Tasks;
using DeveloperTest.Infrastructure.Respositories;
using Xunit;

namespace DeveloperTest.Infrastructure.IntegrationTests.Repositories
{
    public class ColourRepositoryTest : IClassFixture<RepositoryFixture>
    {
        private readonly RepositoryFixture _fixture;

        public ColourRepositoryTest(RepositoryFixture fixture)
        {
            _fixture = fixture;
        }

        [Fact]
        public async Task GetColours_Successfully()
        {
            const int expectedResult = 8;
            var colourRepository = new ColourRepository(_fixture.DeveloperTestContext);
            var result = await colourRepository.GetColours(_fixture.CancellationTokenSource.Token);
            Assert.NotNull(result);
            Assert.Equal(expectedResult,result.Count);
        }
    }
}