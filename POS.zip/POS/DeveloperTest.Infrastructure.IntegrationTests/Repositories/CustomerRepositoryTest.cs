﻿using System.Threading.Tasks;
using DeveloperTest.Core.Models;
using DeveloperTest.Infrastructure.Respositories;
using FluentAssertions;
using Xunit;

namespace DeveloperTest.Infrastructure.IntegrationTests.Repositories
{
    public class CustomerRepositoryTest : IClassFixture<RepositoryFixture>
    {
        private readonly RepositoryFixture _fixture;

        public CustomerRepositoryTest(RepositoryFixture fixture)
        {
            _fixture = fixture;
        }

        [Fact]
        public async Task GetCustomers_Successfully()
        {
            const int expectedResult = 10;
            var customerRepository = new CustomerRepository(_fixture.DeveloperTestContext);
            var result = await customerRepository.GetCustomers(_fixture.CancellationTokenSource.Token);
            Assert.NotNull(result);
            Assert.Equal(expectedResult,result.Count);
        }

        [Fact]
        public async Task GetCustomer_Successfully()
        {
            var expectedResult = new Customer {CustomerId = 1,CustomerName = "John Smith", DiscountGroup = new DiscountGroup(){DiscountGroupId = 6,DiscountGroupName = "None",DiscountPercentage = 0}};
            var customerRepository = new CustomerRepository(_fixture.DeveloperTestContext);
            var result = await customerRepository.GetCustomer(_fixture.CancellationTokenSource.Token,1);
            Assert.NotNull(result);
            result.ShouldBeEquivalentTo(expectedResult);
        }
    }
}