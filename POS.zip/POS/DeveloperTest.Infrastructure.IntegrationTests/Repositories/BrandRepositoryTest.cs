﻿using System.Threading.Tasks;
using DeveloperTest.Infrastructure.Respositories;
using Xunit;

namespace DeveloperTest.Infrastructure.IntegrationTests.Repositories
{
    public class BrandRepositoryTest : IClassFixture<RepositoryFixture>
    {
        private readonly RepositoryFixture _fixture;

        public BrandRepositoryTest(RepositoryFixture fixture)
        {
            _fixture = fixture;
        }

        [Fact]
        public async Task GetBrands_Successfully()
        {
            const int expectedResult = 4;
            var brandRepository = new BrandRepository(_fixture.DeveloperTestContext);
            var result = await brandRepository.GetBrands(_fixture.CancellationTokenSource.Token);
            Assert.NotNull(result);
            Assert.Equal(expectedResult,result.Count);
        }
    }
}