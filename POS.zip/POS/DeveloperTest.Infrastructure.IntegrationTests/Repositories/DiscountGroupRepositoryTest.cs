﻿using System.Threading.Tasks;
using DeveloperTest.Core.Models;
using DeveloperTest.Infrastructure.Respositories;
using FluentAssertions;
using Xunit;

namespace DeveloperTest.Infrastructure.IntegrationTests.Repositories
{
    public class DiscountGroupRepositoryTest : IClassFixture<RepositoryFixture>
    {
        private readonly RepositoryFixture _fixture;

        public DiscountGroupRepositoryTest(RepositoryFixture fixture)
        {
            _fixture = fixture;
        }

        [Fact]
        public async Task GetDiscountGroup_Successfully()
        {
            var expectedResult =
                new DiscountGroup {DiscountGroupId = 1, DiscountGroupName = "Bronze", DiscountPercentage = 5};
            var discountGroupRepository = new DiscountGroupRepository(_fixture.DeveloperTestContext);
            var result = await discountGroupRepository.GetDiscount(_fixture.CancellationTokenSource.Token, 1);
            Assert.NotNull(result);
            result.ShouldBeEquivalentTo(expectedResult);
        }
    }
}