﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DeveloperTest.Infrastructure.Respositories;
using Xunit;
using DeveloperTest.Core.Models;
using FluentAssertions;

namespace DeveloperTest.Infrastructure.IntegrationTests.Repositories
{
    public class ProductRepositoryTest : IClassFixture<RepositoryFixture>
    {
        private readonly RepositoryFixture _fixture;
        private readonly ProductRepository _productRepository;

        public ProductRepositoryTest(RepositoryFixture fixture)
        {
            _fixture = fixture;
            _productRepository = new ProductRepository(_fixture.DeveloperTestContext);
        }

        [Fact]
        public async Task GetCustomerProducts_Successfully_For_SearchParameters()
        {
            var customer = new Customer{ CustomerId = 1, CustomerName = "John Smith", DiscountGroup = new DiscountGroup{DiscountPercentage = 6,DiscountGroupName = "None",DiscountGroupId = 0}};
            var productSearchParameters = new ProductSearchParameters
            {
                BrandIds = new List<int> { 1 },
                SizeIds = new List<int> { 2 },
                ColourIds = new List<int> { 2 },
                SearchString = "Dri"
            };

            var result = await _productRepository.CustomerProductSearch(customer,productSearchParameters, _fixture.CancellationTokenSource.Token);
            Assert.NotNull(result);
            result.Should().Contain(x => x.Brand.Equals("Nike") && x.Colour.Equals("Orange") && x.Size.Equals("S"));

        }
        [Fact]
        public async Task GetProducts_Successfully_For_SearchParameters()
        {
            var productSearchParameters = new ProductSearchParameters
            {
                BrandIds = new List<int> { 1 },
                SizeIds = new List<int> { 2 },
                ColourIds = new List<int> { 7 },
                SearchString = "Dri"
            };

            var result = await _productRepository.ProductSearch(productSearchParameters,_fixture.CancellationTokenSource.Token);
            Assert.NotNull(result);
            result.Should().Contain(x => x.Brand.Equals("Nike") && x.Colour.Equals("Orange") && x.Size.Equals("S"));
           
        }
    }
}