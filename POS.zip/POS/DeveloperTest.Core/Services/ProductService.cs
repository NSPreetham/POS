﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;
using DeveloperTest.Core.Repositories;

namespace DeveloperTest.Core.Services
{
    public class ProductService:IProductService
    {
        private readonly IBrandRepository _brandRepository;
        private readonly IColourRepository _colourRepository;
        private readonly ISizeRepository _sizeRepository;
        private readonly IProductRepository _productRepository;

        public ProductService(IBrandRepository brandRepository, IColourRepository colourRepository,
            ISizeRepository sizeRepository,IProductRepository productRepository)
        {
            _brandRepository = brandRepository;
            _colourRepository = colourRepository;
            _sizeRepository = sizeRepository;
            _productRepository = productRepository;
        }

        /// <summary>
        /// Gets all brands.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All matching brands.</returns>
        public async Task<IList<Brand>> GetBrands(CancellationToken cancellationToken)
        {
            return await _brandRepository.GetBrands(cancellationToken);
        }

        public async Task<IList<Colour>> GetColours(CancellationToken cancellationToken)
        {
            return await _colourRepository.GetColours(cancellationToken);
        }

        public async Task<IList<Size>> GetSizes(CancellationToken cancellationToken)
        {
            return await _sizeRepository.GetSizes(cancellationToken);
        }

        /// <summary>
        /// Performs a search for products using the supplied search parameters and returns a list of Product objects
        /// </summary>
        /// <param name="searchParameters">The product search parameters.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>
        /// All matching products
        /// </returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<IList<Product>> ProductSearch(ProductSearchParameters searchParameters,
                                                 CancellationToken cancellationToken)
        {
            return await _productRepository.ProductSearch(searchParameters, cancellationToken);
        }
    }
}
