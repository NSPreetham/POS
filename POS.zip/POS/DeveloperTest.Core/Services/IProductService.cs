﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;

namespace DeveloperTest.Core.Services
{
    public interface IProductService
    {
        /// <summary>
        /// Performs a search for products using the supplied search parameters and returns a list of Product objects
        /// </summary>
        /// <param name="searchParameters">The product search parameters.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All matching products.</returns>
        Task<IList<Product>> ProductSearch(ProductSearchParameters searchParameters,
            CancellationToken cancellationToken);

        /// <summary>
        /// Gets all brands.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All matching brands.</returns>
        Task<IList<Brand>> GetBrands(CancellationToken cancellationToken);

        /// <summary>
        /// Gets all colours.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All matching colours.</returns>
        Task<IList<Colour>> GetColours(CancellationToken cancellationToken);

        /// <summary>
        /// Gets all sizes.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All matching sizes.</returns>
        Task<IList<Size>> GetSizes(CancellationToken cancellationToken);
        
    }
}
