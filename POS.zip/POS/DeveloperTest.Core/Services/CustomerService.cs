﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;
using DeveloperTest.Core.Repositories;


namespace DeveloperTest.Core.Services
{
    public class CustomerService:ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly IProductRepository _productRepository;

        public CustomerService(ICustomerRepository customerRepository,
            IProductRepository productRepository)
        {
            _customerRepository = customerRepository;
            _productRepository = productRepository;
        }

        /// <summary>
        /// Gets all customers.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>
        /// A list of all customers
        /// </returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<IList<Customer>> GetCustomers(CancellationToken cancellationToken)
        {
            return await _customerRepository.GetCustomers(cancellationToken);
        }

        public async Task<IList<Product>> CustomerProductSearch(int customerId, ProductSearchParameters searchParameters,
            CancellationToken cancellationToken)
        {
            var customer = await _customerRepository.GetCustomer(cancellationToken, customerId);

            if (customer == null)
            {
                throw new KeyNotFoundException($"customer {customerId} not found");
            }

            return await _productRepository.CustomerProductSearch(customer, searchParameters, cancellationToken);
        }
    }
}
