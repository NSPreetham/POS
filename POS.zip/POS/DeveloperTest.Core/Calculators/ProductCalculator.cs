﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeveloperTest.Core.Calculators
{
    public class ProductCalculator.Calculators
    {
        public static decimal CalculateDiscountSellPrice(decimal discountPercentage, decimal linePrice)
        {
            var discountedSellPrice = linePrice - (linePrice * discountPercentage) / 100;
            return discountedSellPrice;
        }
    }
}
