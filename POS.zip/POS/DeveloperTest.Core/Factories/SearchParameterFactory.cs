﻿using System.Collections.Generic;
using System.Linq;
using DeveloperTest.Core.Models;

namespace DeveloperTest.Core.Factories
{
    public class SearchParameterFactory
    {
        public static ProductSearchParameters CreateProductSearchParameters(string[] brandIds, string[] colourIds,
            string[] sizesIds, string searchString)
        {
            return new ProductSearchParameters
            {
                BrandIds = brandIds?.Where(b=>b!=null).Select(int.Parse).ToList() ?? new List<int>(),
                ColourIds = colourIds?.Where(c => c != null).Select(int.Parse).ToList() ?? new List<int>(),
                SizeIds = sizesIds?.Where(s => s != null).Select(int.Parse).ToList() ?? new List<int>(),
                SearchString = searchString
            };
        }
    }
}
