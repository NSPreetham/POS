﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;

namespace DeveloperTest.Core.Repositories
{
    public interface IProductRepository
    {
        /// <summary>
        /// Performs a search for products using the supplied search parameters and returns a list of Product objects
        /// The DiscountedSellPrice for the products is calculated based on the DiscountGroup associated with the
        /// specified customer
        /// </summary>
        /// <param name="customer">The customer</param>
        /// <param name="searchParameters">The product search parameters.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All matching products.</returns>
        Task<IList<Product>> CustomerProductSearch(Customer customer,
            ProductSearchParameters searchParameters,
            CancellationToken cancellationToken);

        /// <summary>
        /// Performs a search for products using the supplied search parameters and returns a list of Product objects
        /// </summary>
        /// <param name="searchParameters">The product search parameters.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All matching products.</returns>
        Task<IList<Product>> ProductSearch(ProductSearchParameters searchParameters,
            CancellationToken cancellationToken);
    }
}
