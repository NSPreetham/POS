﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;

namespace DeveloperTest.Core.
{
    public interface IBrandRepository.Repositories
    {
        /// <summary>
        /// Gets all brands.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All brands.</returns>
        Task<IList<Brand>> GetBrands(CancellationToken cancellationToken);
    }
}
