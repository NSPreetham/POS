﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;

namespace DeveloperTest.Core.Repositories
{
    public interface ISizeRepository
    {
        /// <summary>
        /// Gets all sizes.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All sizes.</returns>
        Task<IList<Size>> GetSizes(CancellationToken cancellationToken);
    }
}
