﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;


namespace DeveloperTest.Core.Repositories
{
    public interface IColourRepository
    {
        /// <summary>
        /// Gets all colours.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All colours.</returns>
        Task<IList<Colour>> GetColours(CancellationToken cancellationToken);
    }
}
