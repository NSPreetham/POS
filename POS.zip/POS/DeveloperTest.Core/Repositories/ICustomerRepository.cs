﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;


namespace DeveloperTest.Core.Repositories
{
    public interface ICustomerRepository 
    {
        /// <summary>
        /// Gets all customers.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>All matching customers.</returns>
        Task<IList<Customer>> GetCustomers(CancellationToken cancellationToken);

        /// <summary>
        /// Gets all customers.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <param name="customerId">Customer unique identifier</param>
        /// <returns>All matching customers.</returns>
        Task<Customer> GetCustomer(CancellationToken cancellationToken, int customerId);

    }
}
