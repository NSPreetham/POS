﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;

namespace DeveloperTest.Core.Repositories
{
    public interface IDiscountGroupRepository 
    {
        /// <summary>
        /// Get discount group.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <param name="discountGroupId"> Unique identifier</param>
        /// <returns>Get discount group for specified discount group Id.</returns>
        Task<DiscountGroup> GetDiscount(CancellationToken cancellationToken, int discountGroupId);
    }
}
