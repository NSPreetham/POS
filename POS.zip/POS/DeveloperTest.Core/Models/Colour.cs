namespace DeveloperTest.Core.Models
{
    /// <summary>
    /// A colour
    /// </summary>
    public class Colour
    {
        /// <summary>
        /// Gets or sets the colour identifier.
        /// </summary>
        /// <value>The colour identifier.</value>
        public int ColourId { get; set; }

        /// <summary>
        /// Gets or sets the name of the colour.
        /// </summary>
        /// <value>The name of the colour.</value>
        public string ColourName { get; set; }

    }
}