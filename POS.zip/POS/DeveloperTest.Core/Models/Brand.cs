namespace DeveloperTest.Core.Models
{
    /// <summary>
    /// A brand
    /// </summary>
    public class Brand
    {
        /// <summary>
        /// Gets or sets the brand identifier.
        /// </summary>
        /// <value>The brand identifier.</value>
        public int BrandId { get; set; }

        /// <summary>
        /// Gets or sets the name of the brand.
        /// </summary>
        /// <value>The name of the brand.</value>
        public string BrandName { get; set; }
        
    }
}