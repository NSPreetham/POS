﻿namespace DeveloperTest.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Product search parameters
    /// </summary>
    public class ProductSearchParameters 
    {
        /// <summary>
        /// Gets or sets the brand ids.
        /// </summary>
        /// <value>The brand ids.</value>
        public List<int> BrandIds { get; set; } = new List<int>();

        /// <summary>
        /// Gets or sets the colour ids.
        /// </summary>
        /// <value>The colour ids.</value>
        public List<int> ColourIds { get; set; } = new List<int>();

        /// <summary>
        /// Gets or sets the search string.
        /// </summary>
        /// <value>The search string.</value>
        public string SearchString { get; set; }

        /// <summary>
        /// Gets or sets the size ids.
        /// </summary>
        /// <value>The size ids.</value>
        public List<int> SizeIds { get; set; } = new List<int>();
        
    }
}