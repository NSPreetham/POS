namespace DeveloperTest.Core.Models
{
    /// <summary>
    /// A size
    /// </summary>
    public class Size 
    {
        /// <summary>
        /// Gets or sets the size identifier.
        /// </summary>
        /// <value>The size identifier.</value>
        public int SizeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the size.
        /// </summary>
        /// <value>The name of the size.</value>
        public string SizeName { get; set; }
    }
}