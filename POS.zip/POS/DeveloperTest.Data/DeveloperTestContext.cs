using Microsoft.EntityFrameworkCore;

namespace DeveloperTest.Data
{
    using System.Data.Entity;
    using System.Data.Entity.ModelConfiguration.Conventions;

    /// <summary>
    /// A context for accessing the DeveloperTest DB
    /// </summary>
    public class DeveloperTestContext : DbContext
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="DeveloperTestContext" /> class.
        /// </summary>
        public DeveloperTestContext() : base("name=DeveloperTestDatabase")
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeveloperTestContext" /> class.
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        public DeveloperTestContext(string connectionString) : base(connectionString)
        {
        }

        

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the brands.
        /// </summary>
        /// <value>The brands.</value>
        public virtual DbSet<Brand> Brands { get; set; }

        /// <summary>
        /// Gets or sets the colours.
        /// </summary>
        /// <value>The colours.</value>
        public virtual DbSet<Colour> Colours { get; set; }

        /// <summary>
        /// Gets or sets the customers.
        /// </summary>
        /// <value>The customers.</value>
        public virtual DbSet<Customer> Customers { get; set; }

        /// <summary>
        /// Gets or sets the discount groups.
        /// </summary>
        /// <value>The discount groups.</value>
        public virtual DbSet<DiscountGroup> DiscountGroups { get; set; }

        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        public virtual DbSet<Product> Products { get; set; }

        /// <summary>
        /// Gets or sets the sizes.
        /// </summary>
        /// <value>The sizes.</value>
        public virtual DbSet<Size> Sizes { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Adds DB specific properties to our POCOs.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // We are working with sets, so pluralise
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            modelBuilder.Entity<Brand>()
                    
                        .Property(brand => brand.BrandName)
                        .IsUnicode(false)
                        .IsRequired()
                        .HasMaxLength(20);

            modelBuilder.Entity<Colour>()
                        .Property(colour => colour.ColourName)
                        .IsUnicode(false)
                        .IsRequired()
                        .HasMaxLength(20);

            modelBuilder.Entity<Customer>()
                        .Property(customer => customer.CustomerName)
                        .IsUnicode(false)
                        .IsRequired()
                        .HasMaxLength(50);

            modelBuilder.Entity<DiscountGroup>()
                        .Property(discountGroup => discountGroup.DiscountGroupName)
                        .IsUnicode(false)
                        .IsRequired()
                        .HasMaxLength(20);

            modelBuilder.Entity<DiscountGroup>()
                        .HasMany(discountGroup => discountGroup.Customers)
                        .WithRequired(customer => customer.DiscountGroup)
                        .WillCascadeOnDelete(false);

            modelBuilder.Entity<Product>()
                        .Property(product => product.ProductName)
                        .IsUnicode(false)
                        .IsRequired()
                        .HasMaxLength(50);

            modelBuilder.Entity<Product>()
                        .Property(product => product.CostPrice)
                        .HasPrecision(19,
                                      4);

            modelBuilder.Entity<Product>()
                        .Property(product => product.SellPrice)
                        .HasPrecision(19,
                                      4);

            modelBuilder.Entity<Size>()
                        .Property(size => size.SizeName)
                        .IsUnicode(false)
                        .IsRequired()
                        .HasMaxLength(20);
        }

        #endregion
    }
}