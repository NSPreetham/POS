﻿namespace DeveloperTest.Data.Migrations
{
    using System.Collections.Generic;
    using System.Data.Entity.Migrations;
    using System.Threading;
    using System.Threading.Tasks;

    /// <summary>
    /// Seeds the database
    /// </summary>
    internal static class TestDataSeeder
    {
        #region Methods

        /// <summary>
        /// Seeds using the specified context.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>Task.</returns>
        public static async Task SeedAsync(DeveloperTestContext context,
                                           CancellationToken cancellationToken)
        {
            await Task.Factory.StartNew(() =>
                                        {
                                            TestDataSeeder.SeedBrands(context);
                                            TestDataSeeder.SeedColours(context);
                                            TestDataSeeder.SeedDiscountGroups(context);
                                            TestDataSeeder.SeedSizes(context);
                                            TestDataSeeder.SeedCustomers(context);
                                            TestDataSeeder.SeedProducts(context);
                                        },
                                        cancellationToken);
        }

        /// <summary>
        /// Seeds the brands.
        /// </summary>
        /// <param name="context">The context.</param>
        private static void SeedBrands(DeveloperTestContext context)
        {
            context.Brands.AddOrUpdate(brand => brand.BrandId,
                                       new Brand
                                       {
                                           BrandId = 1,
                                           BrandName = "Nike"
                                       },
                                       new Brand
                                       {
                                           BrandId = 2,
                                           BrandName = "Adidas"
                                       },
                                       new Brand
                                       {
                                           BrandId = 3,
                                           BrandName = "New Balance"
                                       },
                                       new Brand
                                       {
                                           BrandId = 4,
                                           BrandName = "Saucony"
                                       });
            context.SaveChanges();
        }

        /// <summary>
        /// Seeds the colours.
        /// </summary>
        /// <param name="context">The context.</param>
        private static void SeedColours(DeveloperTestContext context)
        {
            context.Colours.AddOrUpdate(colour => colour.ColourId,
                                        new Colour
                                        {
                                            ColourId = 1,
                                            ColourName = "Red"
                                        },
                                        new Colour
                                        {
                                            ColourId = 2,
                                            ColourName = "Orange"
                                        },
                                        new Colour
                                        {
                                            ColourId = 3,
                                            ColourName = "Yellow"
                                        },
                                        new Colour
                                        {
                                            ColourId = 4,
                                            ColourName = "Green"
                                        },
                                        new Colour
                                        {
                                            ColourId = 5,
                                            ColourName = "Blue"
                                        },
                                        new Colour
                                        {
                                            ColourId = 6,
                                            ColourName = "Pink"
                                        },
                                        new Colour
                                        {
                                            ColourId = 7,
                                            ColourName = "Black"
                                        },
                                        new Colour
                                        {
                                            ColourId = 8,
                                            ColourName = "White"
                                        });
            context.SaveChanges();
        }

        /// <summary>
        /// Seeds the customers.
        /// </summary>
        /// <param name="context">The context.</param>
        private static void SeedCustomers(DeveloperTestContext context)
        {
            context.Customers.AddOrUpdate(customer => customer.CustomerId,
                                          new Customer
                                          {
                                              CustomerId = 1,
                                              CustomerName = "John Smith",
                                              DiscountGroupId = 6
                                          },
                                          new Customer
                                          {
                                              CustomerId = 2,
                                              CustomerName = "Peter Jones",
                                              DiscountGroupId = 6
                                          },
                                          new Customer
                                          {
                                              CustomerId = 3,
                                              CustomerName = "David Stevens",
                                              DiscountGroupId = 1
                                          },
                                          new Customer
                                          {
                                              CustomerId = 4,
                                              CustomerName = "James Edwards",
                                              DiscountGroupId = 5
                                          },
                                          new Customer
                                          {
                                              CustomerId = 5,
                                              CustomerName = "Matthew Campbell",
                                              DiscountGroupId = 3
                                          },
                                          new Customer
                                          {
                                              CustomerId = 6,
                                              CustomerName = "Dean Black",
                                              DiscountGroupId = 2
                                          },
                                          new Customer
                                          {
                                              CustomerId = 7,
                                              CustomerName = "Michael Davis",
                                              DiscountGroupId = 4
                                          },
                                          new Customer
                                          {
                                              CustomerId = 8,
                                              CustomerName = "Sharon Fraser",
                                              DiscountGroupId = 5
                                          },
                                          new Customer
                                          {
                                              CustomerId = 9,
                                              CustomerName = "Megan Gale",
                                              DiscountGroupId = 4
                                          },
                                          new Customer
                                          {
                                              CustomerId = 10,
                                              CustomerName = "Kelly Radcliffe",
                                              DiscountGroupId = 3
                                          });
            context.SaveChanges();
        }

        /// <summary>
        /// Seeds the discount groups.
        /// </summary>
        /// <param name="context">The context.</param>
        private static void SeedDiscountGroups(DeveloperTestContext context)
        {
            context.DiscountGroups.AddOrUpdate(discountGroup => discountGroup.DiscountGroupId,
                                               new DiscountGroup
                                               {
                                                   DiscountGroupId = 1,
                                                   DiscountGroupName = "Bronze",
                                                   DiscountPercentage = 5
                                               },
                                               new DiscountGroup
                                               {
                                                   DiscountGroupId = 2,
                                                   DiscountGroupName = "Silver",
                                                   DiscountPercentage = 10
                                               },
                                               new DiscountGroup
                                               {
                                                   DiscountGroupId = 3,
                                                   DiscountGroupName = "Gold",
                                                   DiscountPercentage = 15
                                               },
                                               new DiscountGroup
                                               {
                                                   DiscountGroupId = 4,
                                                   DiscountGroupName = "Platinum",
                                                   DiscountPercentage = 20
                                               },
                                               new DiscountGroup
                                               {
                                                   DiscountGroupId = 5,
                                                   DiscountGroupName = "VIP",
                                                   DiscountPercentage = 25
                                               },
                                               new DiscountGroup
                                               {
                                                   DiscountGroupId = 6,
                                                   DiscountGroupName = "None",
                                                   DiscountPercentage = 0
                                               });
            context.SaveChanges();
        }

        /// <summary>
        /// Seeds the products.
        /// </summary>
        /// <param name="context">The context.</param>
        private static void SeedProducts(DeveloperTestContext context)
        {
            List<Product> products = new List<Product>();
            products.Add(new Product
                         {
                             ProductId = 2,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 27.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 3,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 28.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 4,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 29.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 5,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 30.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 6,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 7,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 8,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 5,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 9,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 5,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 10,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 5,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 11,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 5,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 12,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 5,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 13,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 5,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 14,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 5,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 15,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 16,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 17,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 18,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 19,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 20,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 8,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 21,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 8,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 22,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 8,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 23,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 8,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 24,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 8,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 25,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 26,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 27,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 28,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 29,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 30,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 31,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 32,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 33,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 34,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 35,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 36,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 37,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 3,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 38,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 3,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 39,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 3,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 40,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 3,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 41,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 3,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 42,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 3,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 43,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 44,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 45,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 46,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 47,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 48,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 1,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 49,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 1,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 50,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 1,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 51,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 1,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 52,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 1,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 53,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 27.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 54,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 28.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 55,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 29.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 56,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 30.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 57,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 58,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 59,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 6,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 60,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 6,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 61,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 6,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 62,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 6,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 63,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 6,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 64,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 6,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 65,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 6,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 66,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 67,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 68,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 69,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 70,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 71,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 1,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 72,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 1,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 73,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 1,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 74,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 1,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 75,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 1,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 76,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 77,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 78,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 79,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 80,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 81,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 82,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 83,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 84,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 85,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 86,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 87,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 88,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 89,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 90,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 91,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 92,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 93,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 4,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 94,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 95,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 96,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 97,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 98,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 99,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 2,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 100,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 2,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 101,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 2,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 102,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 2,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 103,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 2,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 104,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 27.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 1,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 105,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 28.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 1,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 106,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 29.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 1,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 107,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 30.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 1,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 108,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 1,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 109,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 1,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 110,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 111,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 112,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 113,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 114,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 115,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 116,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 7,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 117,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 118,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 119,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 120,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 121,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 4,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 122,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 123,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 124,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 125,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 126,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 2,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 127,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 128,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 129,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 130,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 131,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 132,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 133,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 134,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 135,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 136,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 137,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 138,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 139,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 140,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 141,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 142,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 143,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 144,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 5,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 145,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 8,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 146,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 8,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 147,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 8,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 148,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 8,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 149,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 8,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 150,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 3,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 151,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 3,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 152,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 3,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 153,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 3,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 154,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 3,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 155,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 27.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 2,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 156,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 28.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 2,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 157,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 29.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 2,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 158,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 30.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 2,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 159,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 2,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 160,
                             ProductName = "Dri-FIT Running Vest",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 1,
                             ColourId = 2,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 161,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 162,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 163,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 164,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 165,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 166,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 167,
                             ProductName = "Dri-FIT Shorts",
                             CostPrice = 24.0000m,
                             SellPrice = 29.9900m,
                             BrandId = 1,
                             ColourId = 8,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 168,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 169,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 170,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 171,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 172,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 5,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 173,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 174,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 175,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 176,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 177,
                             ProductName = "Response 3-Stripes Tee",
                             CostPrice = 31.0000m,
                             SellPrice = 38.9900m,
                             BrandId = 2,
                             ColourId = 3,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 178,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 6,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 179,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 6,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 180,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 6,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 181,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 6,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 182,
                             ProductName = "Response 3-Stripes Shorts",
                             CostPrice = 26.0000m,
                             SellPrice = 31.9900m,
                             BrandId = 2,
                             ColourId = 6,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 183,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 184,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 185,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 186,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 187,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 188,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 189,
                             ProductName = "Revel Short Sleeve Tee",
                             CostPrice = 32.0000m,
                             SellPrice = 40.9900m,
                             BrandId = 4,
                             ColourId = 7,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 190,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 191,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 192,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 193,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 194,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 6
                         });
            products.Add(new Product
                         {
                             ProductId = 195,
                             ProductName = "Epic Run Jacket",
                             CostPrice = 43.0000m,
                             SellPrice = 59.9900m,
                             BrandId = 4,
                             ColourId = 6,
                             SizeId = 7
                         });
            products.Add(new Product
                         {
                             ProductId = 196,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 1,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 197,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 1,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 198,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 1,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 199,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 1,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 200,
                             ProductName = "HydraLite Short Sleeve",
                             CostPrice = 31.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 4,
                             ColourId = 1,
                             SizeId = 5
                         });
            products.Add(new Product
                         {
                             ProductId = 201,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 4,
                             SizeId = 1
                         });
            products.Add(new Product
                         {
                             ProductId = 202,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 4,
                             SizeId = 2
                         });
            products.Add(new Product
                         {
                             ProductId = 203,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 4,
                             SizeId = 3
                         });
            products.Add(new Product
                         {
                             ProductId = 204,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 4,
                             SizeId = 4
                         });
            products.Add(new Product
                         {
                             ProductId = 205,
                             ProductName = "CB Tempo Short Sleeve",
                             CostPrice = 32.0000m,
                             SellPrice = 39.9900m,
                             BrandId = 3,
                             ColourId = 4,
                             SizeId = 5
                         });

            context.Products.AddOrUpdate(product => product.ProductId,
                                         products.ToArray());
            context.SaveChanges();
        }

        /// <summary>
        /// Seeds the sizes.
        /// </summary>
        /// <param name="context">The context.</param>
        private static void SeedSizes(DeveloperTestContext context)
        {
            context.Sizes.AddOrUpdate(size => size.SizeId,
                                      new Size
                                      {
                                          SizeId = 1,
                                          SizeName = "XS"
                                      },
                                      new Size
                                      {
                                          SizeId = 2,
                                          SizeName = "S"
                                      },
                                      new Size
                                      {
                                          SizeId = 3,
                                          SizeName = "M"
                                      },
                                      new Size
                                      {
                                          SizeId = 4,
                                          SizeName = "L"
                                      },
                                      new Size
                                      {
                                          SizeId = 5,
                                          SizeName = "XL"
                                      },
                                      new Size
                                      {
                                          SizeId = 6,
                                          SizeName = "XXL"
                                      },
                                      new Size
                                      {
                                          SizeId = 7,
                                          SizeName = "XXXL"
                                      });
            context.SaveChanges();
        }

        #endregion
    }
}