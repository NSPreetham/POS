namespace DeveloperTest.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    using System.Threading;
    using System.Threading.Tasks;

    /// <summary>
    /// Configuration for the DeveloperTestContext. This class cannot be inherited.
    /// </summary>
    public sealed class Configuration : DbMigrationsConfiguration<DeveloperTestContext>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Configuration" /> class.
        /// </summary>
        public Configuration()
        {
            this.AutomaticMigrationsEnabled = true;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Seeds the database with test data. This method will be called after migrating to the latest version.
        /// </summary>
        /// <param name="context">The context.</param>
        protected override void Seed(DeveloperTestContext context)
        {
            // Unfortuantely DbMigrationsConfiguration doesn't support async
            TestDataSeeder.SeedAsync(context,
                                     CancellationToken.None)
                          .Wait();
        }

        

        #endregion
    }
}