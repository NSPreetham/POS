namespace DeveloperTest.Data
{
    /// <summary>
    /// A customer
    /// </summary>
    public class Customer
    {
        #region Properties

        /// <summary>
        /// Gets or sets the customer identifier.
        /// </summary>
        /// <value>The customer identifier.</value>
        public int CustomerId { get; set; }

        /// <summary>
        /// Gets or sets the name of the customer.
        /// </summary>
        /// <value>The name of the customer.</value>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets the discount group.
        /// </summary>
        /// <value>The discount group.</value>
        public virtual DiscountGroup DiscountGroup { get; set; }

        /// <summary>
        /// Gets or sets the discount group identifier.
        /// </summary>
        /// <value>The discount group identifier.</value>
        public int DiscountGroupId { get; set; }

        #endregion
    }
}