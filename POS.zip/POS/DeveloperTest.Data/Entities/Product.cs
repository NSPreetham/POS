namespace DeveloperTest.Data
{
    /// <summary>
    /// A product
    /// </summary>
    public class Product
    {
        #region Properties

        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        public virtual Brand Brand { get; set; }

        /// <summary>
        /// Gets or sets the brand identifier.
        /// </summary>
        /// <value>The brand identifier.</value>
        public int? BrandId { get; set; }

        /// <summary>
        /// Gets or sets the colour.
        /// </summary>
        /// <value>The colour.</value>
        public virtual Colour Colour { get; set; }

        /// <summary>
        /// Gets or sets the colour identifier.
        /// </summary>
        /// <value>The colour identifier.</value>
        public int? ColourId { get; set; }

        /// <summary>
        /// Gets or sets the cost price.
        /// </summary>
        /// <value>The cost price.</value>
        public decimal CostPrice { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>The product identifier.</value>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>The name of the product.</value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the sell price.
        /// </summary>
        /// <value>The sell price.</value>
        public decimal SellPrice { get; set; }

        /// <summary>
        /// Gets or sets the size.
        /// </summary>
        /// <value>The size.</value>
        public virtual Size Size { get; set; }

        /// <summary>
        /// Gets or sets the size identifier.
        /// </summary>
        /// <value>The size identifier.</value>
        public int? SizeId { get; set; }

        #endregion
    }
}