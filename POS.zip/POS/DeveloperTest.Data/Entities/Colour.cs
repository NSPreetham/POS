namespace DeveloperTest.Data
{
    using System.Collections.Generic;

    /// <summary>
    /// A colour
    /// </summary>
    public class Colour
    {
        #region Properties

        /// <summary>
        /// Gets or sets the colour identifier.
        /// </summary>
        /// <value>The colour identifier.</value>
        public int ColourId { get; set; }

        /// <summary>
        /// Gets or sets the name of the colour.
        /// </summary>
        /// <value>The name of the colour.</value>
        public string ColourName { get; set; }

        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        public virtual ICollection<Product> Products { get; set; } = new HashSet<Product>();

        #endregion
    }
}