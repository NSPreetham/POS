namespace DeveloperTest.Data
{
    using System.Collections.Generic;

    /// <summary>
    /// A brand
    /// </summary>
    public class Brand
    {
        #region Properties

        /// <summary>
        /// Gets or sets the brand identifier.
        /// </summary>
        /// <value>The brand identifier.</value>
        public int BrandId { get; set; }

        /// <summary>
        /// Gets or sets the name of the brand.
        /// </summary>
        /// <value>The name of the brand.</value>
        public string BrandName { get; set; }

        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        public virtual ICollection<Product> Products { get; set; } = new HashSet<Product>();

        #endregion
    }
}