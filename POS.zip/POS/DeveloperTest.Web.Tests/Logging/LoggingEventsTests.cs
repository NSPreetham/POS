﻿using DeveloperTest.Web.Logging;
using Xunit;

namespace DeveloperTest.Web.Tests.Logging
{
    public class LoggingEventsTests
    {
        [Fact]
        public void Get_ErrorLog_EventId_Returns_Correct_EventId()
        {
            var eventId = LoggingEvents.GetErrorLogEventId();

            Assert.Equal(999, eventId);
        }

        [Fact]
        public void Get_Request_EventId_Returns_Correct_EventId()
        {
            var eventId = LoggingEvents.GetRequestLogEventId();

            Assert.Equal(888, eventId);
        }

        [Fact]
        public void Get_Response_EventId_Returns_Correct_EventId()
        {
            var eventId = LoggingEvents.GetResponseLogEventId();

            Assert.Equal(777, eventId);
        }
    }
}