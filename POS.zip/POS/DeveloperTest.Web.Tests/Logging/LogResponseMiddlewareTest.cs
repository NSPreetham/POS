using System.IO;
using System.Linq;
using System.Threading.Tasks;
using DeveloperTest.Web.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Internal;
using Moq;
using Xunit;

namespace DeveloperTest.Web.Tests.Logging
{
    public class LogResponseMiddlewareTest
    {
        [Fact]
        public async void Log_Response()
        {
            var loggerMock = new Mock<ILogger<LogResponseMiddleware>>();
            var requestMock = new Mock<HttpRequest>();
            var contextMock = new Mock<HttpContext>();

            requestMock.Setup(x => x.Scheme).Returns("http");
            requestMock.Setup(x => x.Host).Returns(new HostString("localhost"));
            requestMock.Setup(x => x.Path).Returns(new PathString("/home"));
            requestMock.Setup(x => x.PathBase).Returns(new PathString("/"));
            requestMock.Setup(x => x.Method).Returns("GET");
            requestMock.Setup(x => x.Body).Returns(new MemoryStream());

            var responseMock = new Mock<HttpResponse>();

            using (var stream = new MemoryStream())
            {
                var sw = new StreamWriter(stream);
                sw.Write("welcome");
                sw.Flush();
                stream.Position = 0;

                responseMock.Setup(x => x.StatusCode).Returns(200);
                responseMock.Setup(x => x.Body).Returns(stream);

                contextMock.Setup(x => x.Request).Returns(requestMock.Object);
                contextMock.Setup(x => x.Response).Returns(responseMock.Object);

                var logResponseMiddleware = new LogResponseMiddleware(innerHttpContext => Task.FromResult(0)
                    , loggerMock.Object);

                await logResponseMiddleware.Invoke(contextMock.Object);

                loggerMock.Verify(m => m.Log(
                    LogLevel.Information,
                    It.Is<EventId>(x => x.Id == 777),
                    It.Is<FormattedLogValues>(v =>
                        v.Where(x =>
                                x.Key == "Response.StatusCode" && x.Value.ToString() == "200" ||
                                x.Key == "BodyAsText" && x.Value.ToString() == "welcome")
                            .Select(x => x.Value.ToString()).ToList().Count == 2), null, null));
            }
        }
    }
}