using System.IO;
using System.Linq;
using System.Threading.Tasks;
using DeveloperTest.Web.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Internal;
using Moq;
using Xunit;

namespace DeveloperTest.Web.Tests.Logging
{
    public class LogRequestMiddlewareTests
    {
        [Fact]
        public async void Log_Request()
        {
            var loggerMock = new Mock<ILogger<LogRequestMiddleware>>();
            var requestMock = new Mock<HttpRequest>();
            
            requestMock.Setup(x => x.Scheme).Returns("http");
            requestMock.Setup(x => x.Host).Returns(new HostString("localhost"));
            requestMock.Setup(x => x.Path).Returns(new PathString("/home"));
            requestMock.Setup(x => x.PathBase).Returns(new PathString("/"));
            requestMock.Setup(x => x.Method).Returns("GET");
            requestMock.Setup(x => x.Body).Returns(new MemoryStream());

            var contextMock = new Mock<HttpContext>();
            contextMock.Setup(x => x.Request).Returns(requestMock.Object);

            var logRequestMiddleware = new LogRequestMiddleware(innerHttpContext => Task.FromResult(0),
                loggerMock.Object);

            await logRequestMiddleware.Invoke(contextMock.Object);

            loggerMock.Verify(m => m.Log(
                LogLevel.Information,
                It.Is<EventId>(x => x.Id == 888),
                It.Is<FormattedLogValues>(v =>
                    v.Where(x => x.Key == "Request.Path").Select(x => x.Value.ToString()).Contains("/home")),
                null,
                null), Times.Once);
        }
    }
}