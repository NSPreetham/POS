﻿namespace DeveloperTest.Web.MemoryCache
{
    public static class CacheKeys
    {
        public static readonly string CustomerEntry = "_Customer";
        public static readonly string BrandEntry = "_Brand";
        public static readonly string SizeEntry = "_Size";
        public static readonly string ColourEntry = "_Colour";

    }
}
