﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using DeveloperTest.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using DeveloperTest.Web.Exceptions;
using DeveloperTest.Web.Extensions;
using DeveloperTest.Web.Logging;
using Serilog;
using Serilog.Events;

namespace DeveloperTest.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Add framework services.
            services.AddDbContext<DeveloperTestContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DeveloperTestDB")));

            services.AddMemoryCache();
            services.AddMvc();
            services.AddApplicationServices();
            services.AddInfrastructureServices();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            using (var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope())
            {
                if (!serviceScope.ServiceProvider.GetService<DeveloperTestContext>().AllMigrationsApplied())
                {
                    serviceScope.ServiceProvider.GetService<DeveloperTestContext>().Database.Migrate();
                    serviceScope.ServiceProvider.GetService<DeveloperTestContext>().EnsureSeeded();
                }                
            }

            app.UseStaticFiles();

            ConfigureLogging(env);

            app.UseMiddleware<LogRequestMiddleware>();
            app.UseMiddleware<LogResponseMiddleware>();
            app.UseMiddleware<ErrorHandlingMiddleware>();
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }

        private static void ConfigureLogging(IHostingEnvironment env)
        {
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
                .Enrich.WithProperty("Environment", env.EnvironmentName)
                .Enrich.WithProperty("Service", env.ApplicationName)
                .Enrich.FromLogContext()
                .WriteTo
                .File(new Serilog.Formatting.Json.JsonFormatter(), "log.txt")
                .CreateLogger();
        }
    }
}
