﻿using System;
using System.Collections.Generic;
using System.Threading;
using DeveloperTest.Core.Factories;
using DeveloperTest.Core.Models;
using DeveloperTest.Core.Services;
using DeveloperTest.Web.MemoryCache;
using Microsoft.AspNetCore.Mvc;
using DeveloperTest.Web.Models;
using Microsoft.Extensions.Caching.Memory;

namespace DeveloperTest.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ICustomerService _customerService;
        private readonly IProductService _productService;
        private readonly IMemoryCache _memoryCache;

        public HomeController(ICustomerService customerService, IProductService productService,
            IMemoryCache memoryCache)
        {
            _customerService = customerService;
            _productService = productService;
            _memoryCache = memoryCache;
        }

        public IActionResult Index(CancellationToken cancellationToken)
        {
            var model = new ProductViewModel
            {
                CustomerList = PopulateCustomers(cancellationToken),
                BrandList = PopulateBrands(cancellationToken),
                SizeList = PopulateSizes(cancellationToken),
                ColourList = PopulateColours(cancellationToken),
                ProductList = new List<Product>()

            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(CancellationToken cancellationToken, ProductViewModel model)
        {
            model.CustomerList = PopulateCustomers(cancellationToken);
            model.BrandList = PopulateBrands(cancellationToken);
            model.SizeList = PopulateSizes(cancellationToken);
            model.ColourList = PopulateColours(cancellationToken);

            var searchParameters =  SearchParameterFactory.CreateProductSearchParameters(model.BrandIds, model.ColourIds, model.SizeIds,
                model.SearchString);

            model.ProductList = model.CustomerId == null ? _productService.ProductSearch(searchParameters, cancellationToken).Result : _customerService.CustomerProductSearch(int.Parse(model.CustomerId),searchParameters, cancellationToken).Result;

            return View(model);
        }

        private IList<Customer> PopulateCustomers(CancellationToken cancellation)
        {
            var customerList = _memoryCache.GetOrCreate(CacheKeys.CustomerEntry, entry =>
            {
                entry.SlidingExpiration = TimeSpan.FromSeconds(3);
                return _customerService.GetCustomers(cancellation).Result;
            });

            return customerList;
        }

        private IList<Brand> PopulateBrands(CancellationToken cancellation)
        {
            var brandList = _memoryCache.GetOrCreate(CacheKeys.BrandEntry, entry =>
            {
                entry.SlidingExpiration = TimeSpan.FromSeconds(3);
                return _productService.GetBrands(cancellation).Result;
            });

            return brandList;
        }

        private IList<Size> PopulateSizes(CancellationToken cancellation)
        {
            var sizelist = _memoryCache.GetOrCreate(CacheKeys.SizeEntry, entry =>
            {
                entry.SlidingExpiration = TimeSpan.FromSeconds(3);
                return _productService.GetSizes(cancellation).Result;
            });

            return sizelist;
        }

        private IList<Colour> PopulateColours(CancellationToken cancellation)
        {
            var colourList = _memoryCache.GetOrCreate(CacheKeys.ColourEntry, entry =>
            {
                entry.SlidingExpiration = TimeSpan.FromSeconds(3);
                return _productService.GetColours(cancellation).Result;
            });

            return colourList;
        }
    }
}