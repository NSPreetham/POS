using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using DeveloperTest.Web.Logging;

namespace DeveloperTest.Web.Exceptions
{
    public class ErrorHandlingMiddleware
    {
        private readonly ILogger<ErrorHandlingMiddleware> _logger;
        private readonly RequestDelegate _next;

        public ErrorHandlingMiddleware(RequestDelegate next,
            ILogger<ErrorHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, LoggingEvents.GetErrorLogEventId(), "Error Occurred", ex, null);

                await HandleException(context, ex);
            }
        }

        private async Task HandleException(HttpContext context, Exception ex)
        {
            try
            {
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsync(ex.Message);
            }
            catch (Exception e)
            {
                _logger.Log(LogLevel.Error, LoggingEvents.GetErrorLogEventId(), "Handle Exception Error Occurred", e,
                    null);
            }
        }
    }
}