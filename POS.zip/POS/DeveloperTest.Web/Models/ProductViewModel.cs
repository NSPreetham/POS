﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;

namespace DeveloperTest.Web.Models
{
    public class ProductViewModel
    {
        public string[] BrandIds { get; set; }

        public IList<Brand> BrandList { get; set; }

        public string[] SizeIds { get; set; }

        public IList<Size> SizeList { get; set; }

        public string[] ColourIds { get; set; }

        public IList<Colour>ColourList { get; set; }

        public string CustomerId { get; set; }

        public IList<Customer> CustomerList { get; set; }

        public string SearchString { get; set; }

        public IList<Product> ProductList { get; set; }
    }
}
