﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Internal;
using DeveloperTest.Web.Logging;

namespace DeveloperTest.Web.Logging
{
    public class LogResponseMiddleware
    {
        private readonly ILogger<LogResponseMiddleware> _logger;
        private readonly RequestDelegate _next;

        public LogResponseMiddleware(RequestDelegate next, ILogger<LogResponseMiddleware> logger)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            try
            {
                var originalBodyStream = context.Response.Body;

                using (var responseBody = new MemoryStream())
                {
                    context.Response.Body = responseBody;

                    await _next(context);

                    const string message =
                        "Response {BodyAsText} {Response.StatusCode}";

                    var bodyAsText = await FormatResponse(context.Response);
                    _logger.Log(LogLevel.Information,
                        LoggingEvents.GetResponseLogEventId(),
                        new FormattedLogValues(message, bodyAsText, context.Response.StatusCode),
                        null,
                        null);

                    if (context.Response.StatusCode != 204 && context.Response.StatusCode != 304)
                        await responseBody.CopyToAsync(originalBodyStream);
                }
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, LoggingEvents.GetErrorLogEventId(), "Response Error Occurred", ex, null);
            }
        }

        private static async Task<string> FormatResponse(HttpResponse response)
        {
            response.Body.Seek(0, SeekOrigin.Begin);
            var bodyAsText = await new StreamReader(response.Body).ReadToEndAsync();
            response.Body.Seek(0, SeekOrigin.Begin);
            return bodyAsText;
        }
    }
}