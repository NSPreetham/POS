﻿using System;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Internal;
using DeveloperTest.Web.Logging;

namespace DeveloperTest.Web.Logging
{
    public class LogRequestMiddleware
    {
        private readonly ILogger<LogRequestMiddleware> _logger;
        private readonly RequestDelegate _next;

        public LogRequestMiddleware(RequestDelegate next, ILogger<LogRequestMiddleware> logger)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));

            try
            {
                    var bodyAsText = await GetBodyText(context.Request);
                    const string message =
                        "Request {Request.Host} {Request.Path} {Request.QueryString} {Request.Method} {BodyAsText}";

                    _logger.Log(LogLevel.Information,
                        LoggingEvents.GetRequestLogEventId(),
                        new FormattedLogValues(message, context.Request.Host, context.Request.Path,
                            context.Request.QueryString, context.Request.Method, bodyAsText), null, null);
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, LoggingEvents.GetErrorLogEventId(), "Request Error Occurred", ex, null);
            }
        }

        private static async Task<string> GetBodyText(HttpRequest request)
        {
            request.EnableRewind();
            var buffer = new byte[Convert.ToInt32(request.ContentLength)];
            await request.Body.ReadAsync(buffer, 0, buffer.Length);
            var bodyAsText = Encoding.UTF8.GetString(buffer);
            request.Body.Position = 0;
            return bodyAsText;
        }
    }
}