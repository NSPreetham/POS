﻿using System.Collections.Generic;

namespace DeveloperTest.Web.Logging
{
    public static class LoggingEvents
    {
        private static readonly Dictionary<string, int> LogEvents = new Dictionary<string, int>
        {
            {"RESPONSE", 777},
            {"REQUEST", 888},
            {"ERROR", 999}
        };

        public static int GetErrorLogEventId()
        {
            return LogEvents.GetValueOrDefault("ERROR");
        }

        public static int GetRequestLogEventId()
        {
            return LogEvents.GetValueOrDefault("REQUEST");
        }

        public static int GetResponseLogEventId()
        {
            return LogEvents.GetValueOrDefault("RESPONSE");
        }
    }
}