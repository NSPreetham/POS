﻿using System;
using DeveloperTest.Core.Services;
using Microsoft.Extensions.DependencyInjection;

namespace DeveloperTest.Web.Extensions
{

    public static class ApplicationServiceCollectionExtensions
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            if (services == null)
                throw new ArgumentNullException(nameof(services));

            services.AddTransient<ICustomerService, CustomerService>();
            services.AddTransient<IProductService, ProductService>();
            
            return services;
        }
    }
}

