﻿using System;
using DeveloperTest.Core.Repositories;
using DeveloperTest.Infrastructure.Data;
using DeveloperTest.Infrastructure.Respositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace DeveloperTest.Web.Extensions
{
    public static class InfratructureServiceCollectionExtensions
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services)
        {
            if (services == null)
                throw new ArgumentNullException(nameof(services));

            services.AddScoped(typeof(ICustomerRepository), typeof(CustomerRepository));
            services.AddScoped(typeof(IProductRepository), typeof(ProductRepository));
            services.AddScoped(typeof(IBrandRepository), typeof(BrandRepository));
            services.AddScoped(typeof(ISizeRepository), typeof(SizeRepository));
            services.AddScoped(typeof(IDiscountGroupRepository), typeof(DiscountGroupRepository));
            services.AddScoped(typeof(IColourRepository), typeof(ColourRepository));
            services.AddScoped<DbContext, DeveloperTestContext>();

            return services;
        }
    }
}