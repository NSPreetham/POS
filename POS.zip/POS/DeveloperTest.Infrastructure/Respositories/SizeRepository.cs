﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using DeveloperTest.Core.Repositories;
using DeveloperTest.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Size = DeveloperTest.Core.Models.Size;
using SizeEntity = DeveloperTest.Infrastructure.Data.Entities.Size;

namespace DeveloperTest.Infrastructure.Respositories
{
    public class SizeRepository : ISizeRepository
    {
        private readonly DeveloperTestContext _context;

        public SizeRepository(DeveloperTestContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Gets all sizes.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>
        /// A list of all sizes
        /// </returns>
        public async Task<IList<Size>> GetSizes(CancellationToken cancellationToken)
        {
            var sizes = await _context.Sizes.AsQueryable().ToListAsync(cancellationToken);
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<SizeEntity, Size>(); });
            var sizeConfig = config.CreateMapper();
            return sizeConfig.Map<List<SizeEntity>, List<Size>>(sizes);
        }
    }
}