﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using DeveloperTest.Core.Models;
using DeveloperTest.Core.Repositories;
using DeveloperTest.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Customer = DeveloperTest.Core.Models.Customer;
using CustomerEntity = DeveloperTest.Infrastructure.Data.Entities.Customer;

namespace DeveloperTest.Infrastructure.Respositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly DeveloperTestContext _context;

        public CustomerRepository(DeveloperTestContext context)
        {
            _context = context;
        }

        public async Task<Customer> GetCustomer(CancellationToken cancellationToken, int customerId)
        {
            var customer = await _context.Customers
                .Include(c => c.DiscountGroup)
                .Where(c=>c.CustomerId == customerId ).AsQueryable().FirstOrDefaultAsync(cancellationToken);
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<CustomerEntity, Customer>(); });
            var customerConfig = config.CreateMapper();
            return customerConfig.Map<CustomerEntity, Customer>(customer);
        }

        /// <summary>
        /// Gets all customers.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>
        /// A list of all customers
        /// </returns>
        public async Task<IList<Customer>> GetCustomers(CancellationToken cancellationToken)
        {
            var customers = await _context.Customers.AsQueryable().ToListAsync(cancellationToken);
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<CustomerEntity, Customer>(); });
            var customerConfig = config.CreateMapper();
            return customerConfig.Map<List<CustomerEntity>, List<Customer>>(customers);
        }
    }
}