﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using DeveloperTest.Core.Calculators;
using DeveloperTest.Core.Models;
using DeveloperTest.Core.Repositories;
using DeveloperTest.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Product = DeveloperTest.Core.Models.Product;
using ProductEntity = DeveloperTest.Infrastructure.Data.Entities.Product;
using BrandEntity = DeveloperTest.Infrastructure.Data.Entities.Brand;


namespace DeveloperTest.Infrastructure.Respositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly DeveloperTestContext _context;
        
        public ProductRepository(DeveloperTestContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Performs a search for products using the supplied search parameters and returns a list of Product objects
        /// The DiscountedSellPrice for the products is calculated based on the DiscountGroup associated with the
        /// specified customer
        /// </summary>
        /// <param name="customer">The customer id.</param>
        /// <param name="searchParameters">The product search parameters.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>
        /// A list of all matching products
        /// </returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<IList<Product>> CustomerProductSearch(Customer customer,
            ProductSearchParameters searchParameters,
            CancellationToken cancellationToken)
        {
            var keywords = searchParameters.SearchString == null
                ? new string[0]
                : searchParameters.SearchString.Split(' ');

            var products = await _context.Products
                .Include(product => product.Brand)
                .Include(product => product.Colour)
                .Include(product => product.Size)
                .Where(p =>
                    (searchParameters.BrandIds.Count == 0 || searchParameters.BrandIds.Contains(p.Brand.BrandId))
                    && (searchParameters.SizeIds.Count == 0 || searchParameters.SizeIds.Contains(p.Size.SizeId))
                    && (searchParameters.ColourIds.Count == 0 || searchParameters.SizeIds.Contains(p.Colour.ColourId))
                    && (keywords.Length == 0 || keywords.All(k =>
                            p.ProductName.Contains(k) || p.Size.SizeName.Contains(k) ||
                            p.Colour.ColourName.Contains(k) || p.Brand.BrandName.Contains(k))))

                .Select(product =>
                    new Product
                    {
                        ProductId = product.ProductId,
                        ProductName = product.ProductName,
                        Size = product.Size.SizeName,
                        Brand = product.Brand.BrandName,
                        Colour = product.Colour.ColourName,
                        CostPrice = product.CostPrice,
                        SellPrice = product.SellPrice,
                        DiscountedSellPrice = ProductCalculator.CalculateDiscountSellPrice(customer.DiscountGroup.DiscountPercentage,
                            product.SellPrice) > product.CostPrice? 
                            ProductCalculator.CalculateDiscountSellPrice(customer.DiscountGroup.DiscountPercentage,
                                product.SellPrice):product.CostPrice
                    }).ToListAsync(cancellationToken);

            return products;
        }



        /// <summary>
        /// Performs a search for products using the supplied search parameters and returns a list of Product objects
        /// </summary>
        /// <param name="searchParameters">The product search parameters.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>
        /// All matching products
        /// </returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<IList<Product>> ProductSearch(ProductSearchParameters searchParameters,
            CancellationToken cancellationToken)
        {

            var keywords = searchParameters.SearchString == null
                ? new string[0]
                : searchParameters.SearchString.Split(' ');

            var products = await _context.Products
                .Include(product => product.Brand)
                .Include(product => product.Colour)
                .Include(product => product.Size)
                .Where(p =>
                    (searchParameters.BrandIds.Count == 0 || searchParameters.BrandIds.Contains(p.Brand.BrandId))
                    && (searchParameters.SizeIds.Count == 0 || searchParameters.SizeIds.Contains(p.Size.SizeId))
                    && (searchParameters.ColourIds.Count == 0 || searchParameters.SizeIds.Contains(p.Colour.ColourId))
                    && (keywords.Length == 0 || keywords.All(k =>
                            p.ProductName.Contains(k) || p.Size.SizeName.Contains(k) ||
                            p.Colour.ColourName.Contains(k) || p.Brand.BrandName.Contains(k))))

                .ToListAsync(cancellationToken);

            var mapperConfiguration = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<ProductEntity, Product>()
                    .ForMember(x => x.Brand, opts => opts.MapFrom(x => x.Brand.BrandName))
                    .ForMember(x => x.Size, opts => opts.MapFrom(x => x.Size.SizeName))
                    .ForMember(x => x.Colour, opts => opts.MapFrom(x => x.Colour.ColourName));
            });
            var productConfig = mapperConfiguration.CreateMapper();
            return productConfig.Map<List<ProductEntity>, List<Product>>(products);
        }
    }
}
