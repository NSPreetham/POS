﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using DeveloperTest.Core.Models;
using DeveloperTest.Core.Repositories;
using DeveloperTest.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using DiscountGroup = DeveloperTest.Core.Models.DiscountGroup;
using DiscountGroupEntity = DeveloperTest.Infrastructure.Data.Entities.DiscountGroup;

namespace DeveloperTest.Infrastructure.Respositories
{
    public class DiscountGroupRepository : IDiscountGroupRepository
    {
        private readonly DeveloperTestContext _context;

        public DiscountGroupRepository(DeveloperTestContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Get discount group.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <param name="discountGroupId"> Unique identifier</param>
        /// <returns>Get discount group for specified discount group Id.</returns>
        public async Task<DiscountGroup> GetDiscount(CancellationToken cancellationToken, int discountGroupId)
        {
            var discountGroup = await _context.DiscountGroups
                                .Where(d=>d.DiscountGroupId == discountGroupId)
                                .AsQueryable().FirstOrDefaultAsync(cancellationToken);
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<DiscountGroup, Brand>(); });
            var brandConfig = config.CreateMapper();
            return brandConfig.Map<DiscountGroupEntity, DiscountGroup>(discountGroup);
        }
    }
}