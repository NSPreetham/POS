﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using DeveloperTest.Core.Repositories;
using DeveloperTest.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Colour = DeveloperTest.Core.Models.Colour;
using ColourEntity = DeveloperTest.Infrastructure.Data.Entities.Colour;

namespace DeveloperTest.Infrastructure.Respositories
{
    public class ColourRepository : IColourRepository
    {
        private readonly DeveloperTestContext _context;

        public ColourRepository(DeveloperTestContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Gets all colours.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>
        /// A list of all colours
        /// </returns>
        public async Task<IList<Colour>> GetColours(CancellationToken cancellationToken)
        {
            var colours = await _context.Colours.AsQueryable().ToListAsync(cancellationToken);
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<ColourEntity, Colour>(); });
            var colourConfig = config.CreateMapper();
            return colourConfig.Map<List<ColourEntity>, List<Colour>>(colours);
        }
    }
}