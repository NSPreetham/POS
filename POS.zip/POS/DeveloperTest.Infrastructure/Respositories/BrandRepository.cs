﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using DeveloperTest.Core.Repositories;
using DeveloperTest.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Brand = DeveloperTest.Core.Models.Brand;
using BrandEntity = DeveloperTest.Infrastructure.Data.Entities.Brand;

namespace DeveloperTest.Infrastructure.Respositories
{
    public class BrandRepository : IBrandRepository
    {
        private readonly DeveloperTestContext _context;

        public BrandRepository(DeveloperTestContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Gets all brands.
        /// </summary>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>
        /// A list of all brands
        /// </returns>
        public async Task<IList<Brand>> GetBrands(CancellationToken cancellationToken)
        {
            var brands = await _context.Brands.AsQueryable().ToListAsync(cancellationToken);
            var config = new MapperConfiguration(cfg => { cfg.CreateMap<BrandEntity, Brand>(); });
            var brandConfig = config.CreateMapper();
            return brandConfig.Map<List<BrandEntity>, List<Brand>>(brands);
        }
    }
}