using System.Collections.Generic;

namespace DeveloperTest.Infrastructure.Data.Entities
{
    /// <summary>
    /// A product
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        public Brand Brand { get; set; }

        /// <summary>
        /// Gets or sets the brand identifier.
        /// </summary>
        /// <value>The brand identifier.</value>
        public int BrandId { get; set; }

        /// <summary>
        /// Gets or sets the colour.
        /// </summary>
        /// <value>The colour.</value>
        public Colour Colour { get; set; }

        /// <summary>
        /// Gets or sets the colour identifier.
        /// </summary>
        /// <value>The colour identifier.</value>
        public int ColourId { get; set; }

        /// <summary>
        /// Gets or sets the cost price.
        /// </summary>
        /// <value>The cost price.</value>
        public decimal CostPrice { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>The product identifier.</value>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>The name of the product.</value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the sell price.
        /// </summary>
        /// <value>The sell price.</value>
        public decimal SellPrice { get; set; }

        /// <summary>
        /// Gets or sets the size.
        /// </summary>
        /// <value>The size.</value>
        public Size Size { get; set; }

        /// <summary>
        /// Gets or sets the size identifier.
        /// </summary>
        /// <value>The size identifier.</value>
        public int SizeId { get; set; }

        /// <summary>
        /// Gets or sets the sale items.
        /// </summary>
        /// <value>The sale items.</value>
        public ICollection<SaleItem> SaleItems { get; set; }
        
        /// <summary>
        /// Gets or sets the stock.
        /// </summary>
        /// <value>The stock.</value>
        public ICollection<Stock> Stocks { get; set; }
        
    }
}