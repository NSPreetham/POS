using System;

namespace DeveloperTest.Infrastructure.Data.Entities
{
    using System.Collections.Generic;

    /// <summary>
    /// A Stock
    /// </summary>
    public class Stock
    {  
        /// <summary>
        /// Gets or sets the stock identifier.
        /// </summary>
        /// <value>The sale identifier.</value>
        public int StockId { get; set; }

        /// <summary>
        /// Gets or sets the stock level
        /// </summary>
        /// <value>Stock level</value>
        public int StockLevel { get; set; }

        /// <summary>
        /// Gets or sets the minimum stock level
        /// </summary>
        /// <value>Min Stock level</value>
        public int StockLevelMin { get; set; }

        /// <summary>
        /// Gets or sets the minimum stock level
        /// </summary>
        /// <value>Min Stock level</value>
        public int StockLevelMax { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>Product identifier.</value>
        public int ProductId { get; set; }
        
        /// <summary>
        /// Gets or sets the product.
        /// </summary>
        /// <value>The product.</value>
        public Product Product { get; set; }
        
    }
}