namespace DeveloperTest.Infrastructure.Data.Entities
{
    using System.Collections.Generic;

    /// <summary>
    /// A payment type
    /// </summary>
    public class PaymentType
    {
        /// <summary>
        /// Gets or sets the payment type identifier.
        /// </summary>
        /// <value>The payment type identifier.</value>
        public int PaymentTypeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the payment type.
        /// </summary>
        /// <value>payment type</value>
        public string PaymentTypeName { get; set; }

        /// <summary>
        /// Gets or sets open cash drawer.
        /// </summary>
        /// <value>Open cash drawer</value>
        public bool OpenCashDrawer { get; set; }

        /// <summary>
        /// Gets or sets EFT
        /// </summary>
        /// <value>EFT</value>
        public bool Eft { get; set; }

        /// <summary>
        /// Gets or setsPromptCashOut
        /// </summary>
        /// <value>PromptCashOut</value>
        public bool PromptCashOut { get; set; }

        /// <summary>
        /// Gets or sets the payments.
        /// </summary>
        /// <value>The payments.</value>
        public ICollection<Payment> Payments { get; set; }
    }
}