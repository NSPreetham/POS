namespace DeveloperTest.Infrastructure.Data.Entities
{
    using System.Collections.Generic;

    /// <summary>
    /// A Sale Item
    /// </summary>
    public class SaleItem
    {  
        /// <summary>
        /// Gets or sets the sale item identifier.
        /// </summary>
        /// <value>The sales point identifier.</value>
        public int SaleItemId { get; set; }

        /// <summary>
        /// Gets or sets the sale identifier.
        /// </summary>
        /// <value>The sale item identifier.</value>
        public int SaleId { get; set; }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>The quantity.</value>
        public int Quantity { get; set; }

        /// <summary>
        /// Gets or sets the full price.
        /// </summary>
        /// <value>The full price.</value>
        public decimal FullPrice { get; set; }

        /// <summary>
        /// Gets or sets the discount.
        /// </summary>
        /// <value>The discount.</value>
        public decimal Discount { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>The product identifier.</value>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets the sale.
        /// </summary>
        /// <value>The sale.</value>
        public Sale Sale { get; set; }
        
        /// <summary>
        /// Gets or sets the product.
        /// </summary>
        /// <value>The product.</value>
        public Product Product { get; set; }

    }
}