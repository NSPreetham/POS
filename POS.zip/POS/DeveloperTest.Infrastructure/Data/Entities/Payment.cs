namespace DeveloperTest.Infrastructure.Data.Entities
{
    using System.Collections.Generic;

    /// <summary>
    /// A Payment
    /// </summary>
    public class Payment
    {  
        /// <summary>
        /// Gets or sets the payment identifier.
        /// </summary>
        /// <value>The payment identifier.</value>
        public int PaymentId { get; set; }

        /// <summary>
        /// Gets or sets the sales identifier.
        /// </summary>
        /// <value>The sales identifier.</value>
        public int SaleId { get; set; }

        /// <summary>
        /// Gets or sets the payment type identifier.
        /// </summary>
        /// <value>The payment type identifier.</value>
        public int PaymentTypeId { get; set; }

        /// <summary>
        /// Gets or sets the amount.
        /// </summary>
        /// <value>The sales point identifier.</value>
        public decimal Amount { get; set; }
    
        /// <summary>
        /// Gets or sets the sales.
        /// </summary>
        /// <value>The sales.</value>
        public Sale Sale { get; set; }

        /// <summary>
        /// Gets or sets the payment type.
        /// </summary>
        /// <value>The payment type.</value>
        public PaymentType PaymentType { get; set; }


    }
}