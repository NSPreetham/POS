namespace DeveloperTest.Infrastructure.Data.Entities
{
    using System.Collections.Generic;

    /// <summary>
    /// A size
    /// </summary>
    public class Size
    {
        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        public ICollection<Product> Products { get; set; } = new HashSet<Product>();

        /// <summary>
        /// Gets or sets the size identifier.
        /// </summary>
        /// <value>The size identifier.</value>
        public int SizeId { get; set; }

        /// <summary>
        /// Gets or sets the name of the size.
        /// </summary>
        /// <value>The name of the size.</value>
        public string SizeName { get; set; }

    }
}