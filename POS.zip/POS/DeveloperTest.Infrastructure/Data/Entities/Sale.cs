using System;

namespace DeveloperTest.Infrastructure.Data.Entities
{
    using System.Collections.Generic;

    /// <summary>
    /// A Sale
    /// </summary>
    public class Sale
    {  
        /// <summary>
        /// Gets or sets the sale identifier.
        /// </summary>
        /// <value>The sale identifier.</value>
        public int SaleId { get; set; }

        /// <summary>
        /// Gets or sets the sale date.
        /// </summary>
        /// <value>Sale date.</value>
        public DateTime SaleDate { get; set; }

        /// <summary>
        /// Gets or sets the sale person identifier.
        /// </summary>
        /// <value>The sale person identifier.</value>
        public int SalePersonId { get; set; }

       
        /// <summary>
        /// Gets or sets the payments.
        /// </summary>
        /// <value>The payment.</value>
        public ICollection<Payment> Payments { get; set; }

        /// <summary>
        /// Gets or sets the sale items.
        /// </summary>
        /// <value>The sale items.</value>
        public ICollection<SaleItem> SaleItems { get; set; }

    }
}