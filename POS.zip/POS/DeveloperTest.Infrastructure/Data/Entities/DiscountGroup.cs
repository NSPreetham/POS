namespace DeveloperTest.Infrastructure.Data.Entities
{
    using System.Collections.Generic;

    /// <summary>
    /// A discount group
    /// </summary>
    public class DiscountGroup
    {
        
        /// <summary>
        /// Gets or sets the customers.
        /// </summary>
        /// <value>The customers.</value>
        public ICollection<Customer> Customers { get; set; }

        /// <summary>
        /// Gets or sets the discount group identifier.
        /// </summary>
        /// <value>The discount group identifier.</value>
        public int DiscountGroupId { get; set; }

        /// <summary>
        /// Gets or sets the name of the discount group.
        /// </summary>
        /// <value>The name of the discount group.</value>
        public string DiscountGroupName { get; set; }

        /// <summary>
        /// Gets or sets the discount percentage.
        /// </summary>
        /// <value>The discount percentage.</value>
        public byte DiscountPercentage { get; set; }

    }
}