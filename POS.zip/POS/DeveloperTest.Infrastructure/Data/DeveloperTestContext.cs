﻿using DeveloperTest.Infrastructure.Data.Entities;
using DeveloperTest.Infrastructure.Data.EntityMaps;
using Microsoft.EntityFrameworkCore;

namespace DeveloperTest.Infrastructure.Data
{
    public class DeveloperTestContext:DbContext
    {
        public DeveloperTestContext()
        {
        }

        public DeveloperTestContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Please do NOT remove this otherwise 'dotnet ef migrations' will fail
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("does not matter");
            }
        }

        /// <summary>
        /// Adds DB specific properties to our POCOs.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            BrandMap.Map(modelBuilder.Entity<Brand>());
            CustomerMap.Map(modelBuilder.Entity<Customer>());
            SizeMap.Map(modelBuilder.Entity<Size>());
            ColourMap.Map(modelBuilder.Entity<Colour>());
            DiscountGroupMap.Map(modelBuilder.Entity<DiscountGroup>());
            ProductMap.Map(modelBuilder.Entity<Product>());
            SaleMap.Map(modelBuilder.Entity<Sale>());
            SaleItemMap.Map(modelBuilder.Entity<SaleItem>());
            PaymentTypeMap.Map(modelBuilder.Entity<PaymentType>());
            PaymentMap.Map(modelBuilder.Entity<Payment>());
            StockMap.Map(modelBuilder.Entity<Stock>());
            
            base.OnModelCreating(modelBuilder);
        }

        /// <summary>
        /// Gets or sets the brands.
        /// </summary>
        /// <value>The brands.</value>
        public DbSet<Brand> Brands { get; set; }

        /// <summary>
        /// Gets or sets the colours.
        /// </summary>
        /// <value>The colours.</value>
        public DbSet<Colour> Colours { get; set; }

        /// <summary>
        /// Gets or sets the customers.
        /// </summary>
        /// <value>The customers.</value>
        public DbSet<Customer> Customers { get; set; }

        /// <summary>
        /// Gets or sets the discount groups.
        /// </summary>
        /// <value>The discount groups.</value>
        public DbSet<DiscountGroup> DiscountGroups { get; set; }

        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        public DbSet<Product> Products { get; set; }

        /// <summary>
        /// Gets or sets the payments.
        /// </summary>
        /// <value>The payments.</value>
        public DbSet<Payment> Payments { get; set; }

        /// <summary>
        /// Gets or sets the sizes.
        /// </summary>
        /// <value>The sizes.</value>
        public DbSet<Size> Sizes { get; set; }

        /// <summary>
        /// Gets or sets the payment type.
        /// </summary>
        /// <value>The payments.</value>
        public DbSet<PaymentType> PaymentTypes { get; set; }

        /// <summary>
        /// Gets or sets the sale.
        /// </summary>
        /// <value>The sale.</value>
        public DbSet<Sale> Sales { get; set; }

        /// <summary>
        /// Gets or sets the sale item.
        /// </summary>
        /// <value>The sale item.</value>
        public DbSet<SaleItem> SaleItem { get; set; }

        /// <summary>
        /// Gets or sets the stock.
        /// </summary>
        /// <value>The stock.</value>
        public DbSet<Stock> Stock { get; set; }
    }
}
