﻿using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class PaymentMap
    {
        public static void Map(EntityTypeBuilder<Payment> builder)
        {
            builder
                .ToTable("Payment");
            builder
                .Property(payment => payment.Amount)
                .HasPrecision(19,
                    4);

        }
    }
}
