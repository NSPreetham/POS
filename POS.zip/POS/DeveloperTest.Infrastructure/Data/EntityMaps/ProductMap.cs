﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class ProductMap
    {
        public static void Map(EntityTypeBuilder<Product> builder)
        {
            builder
                .ToTable("Product")
                .Property(product => product.ProductName)
                .IsUnicode(false)
                .IsRequired()
                .HasMaxLength(50);

            builder
                .Property(product => product.CostPrice)
                .HasPrecision(19,
                    4);

            builder
                .Property(product => product.SellPrice)
                .HasPrecision(19,
                    4);

            
        }
    }
}
