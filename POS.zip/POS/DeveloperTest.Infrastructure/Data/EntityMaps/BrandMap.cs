﻿using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class BrandMap
    {
        public static void Map(EntityTypeBuilder<Brand> builder)
        {
            builder
                .ToTable("Brand")
                .Property(brand => brand.BrandName)
                .IsUnicode(false)
                .IsRequired()
                .HasMaxLength(20);
        }
    }
}
