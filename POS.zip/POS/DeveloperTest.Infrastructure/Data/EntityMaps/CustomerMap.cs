﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class CustomerMap
    {
        public static void Map(EntityTypeBuilder<Customer> builder)
        {
            builder
                .ToTable("Customer")
                .Property(customer => customer.CustomerName)
                .IsUnicode(false)
                .IsRequired()
                .HasMaxLength(50);
        }
    }
}
