﻿using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class PaymentTypeMap
    {
        public static void Map(EntityTypeBuilder<PaymentType> builder)
        {
            builder
                .ToTable("PaymentType")
                .Property(paymentType => paymentType.PaymentTypeName)
                .IsUnicode(false)
                .IsRequired()
                .HasMaxLength(20);
        }
    }
}
