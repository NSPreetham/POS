﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class DiscountGroupMap
    {
        public static void Map(EntityTypeBuilder<DiscountGroup> builder)
        {
            builder
                .ToTable("DiscountGroup")
                .Property(discountGroup => discountGroup.DiscountGroupName)
                .IsUnicode(false)
                .IsRequired()
                .HasMaxLength(20);
        }
    }
}
