﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class SizeMap
    {
        public static void Map(EntityTypeBuilder<Size> builder)
        {
            builder
                .ToTable("Size")
                .Property(size => size.SizeName)
                .IsUnicode(false)
                .IsRequired()
                .HasMaxLength(20);
        }
    }
}
