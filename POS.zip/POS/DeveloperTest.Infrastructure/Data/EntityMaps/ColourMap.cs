﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class ColourMap
    {
        public static void Map(EntityTypeBuilder<Colour> builder)
        {
            builder
                .ToTable("Colour")
                .Property(colour => colour.ColourName)
                .IsUnicode(false)
                .IsRequired()
                .HasMaxLength(20);
        }
    }
}
