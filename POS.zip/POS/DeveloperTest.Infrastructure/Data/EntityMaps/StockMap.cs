﻿using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class StockMap
    {
        public static void Map(EntityTypeBuilder<Stock> builder)
        {
            builder
                .ToTable("Stock");

        }
    }
}
