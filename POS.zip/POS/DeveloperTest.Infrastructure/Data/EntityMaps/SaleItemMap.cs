﻿using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using DeveloperTest.Infrastructure.Data.Entities;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DeveloperTest.Infrastructure.Data.EntityMaps
{
    public class SaleItemMap
    {
        public static void Map(EntityTypeBuilder<SaleItem> builder)
        {
            builder
                .ToTable("SaleItem");

            builder
                .Property(saleItem => saleItem.FullPrice)
                .HasPrecision(19,
                    4);
            builder
                .Property(saleItem => saleItem.Discount)
                .HasPrecision(19,
                    4);
            
        }
    }
}
