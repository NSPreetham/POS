﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using CustomerEntity = DeveloperTest.Infrastructure.Data.Entities.Customer;
using ProductEntity = DeveloperTest.Infrastructure.Data.Entities.Product;
using ColourEntity = DeveloperTest.Infrastructure.Data.Entities.Colour;
using BrandEntity = DeveloperTest.Infrastructure.Data.Entities.Brand;
using SizeEntity = DeveloperTest.Infrastructure.Data.Entities.Size;
using DiscountGroupEntity = DeveloperTest.Infrastructure.Data.Entities.DiscountGroup;
using PaymentEntity = DeveloperTest.Infrastructure.Data.Entities.Payment;
using PaymentTypeEntity = DeveloperTest.Infrastructure.Data.Entities.PaymentType;
using SaleEntity = DeveloperTest.Infrastructure.Data.Entities.Sale;
using SaleItemEntity = DeveloperTest.Infrastructure.Data.Entities.SaleItem;
using StockEntity = DeveloperTest.Infrastructure.Data.Entities.Stock;


namespace DeveloperTest.Infrastructure.Data
{
    public static class DeveloperTestContextExtension
    {

        public static bool AllMigrationsApplied(this DbContext context)
        {
            var applied = context.GetService<IHistoryRepository>()
                .GetAppliedMigrations()
                .Select(m => m.MigrationId);

            var total = context.GetService<IMigrationsAssembly>()
                .Migrations
                .Select(m => m.Key);

            return !total.Except(applied).Any();
        }

        public static void EnsureSeeded(this DeveloperTestContext context)
        {
            if (!context.Brands.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Brand ON");
                var brands =
                    JsonConvert.DeserializeObject<List<BrandEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}brands.json"));
                context.AddRange(brands);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Brand OFF");
                context.Database.CloseConnection();
            }

            if (!context.Colours.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Colour ON");
                var colours =
                    JsonConvert.DeserializeObject<List<ColourEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}colours.json"));
                context.AddRange(colours);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Colour OFF");
                context.Database.CloseConnection();
            }

            if (!context.DiscountGroups.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.DiscountGroup ON");
                var discountGroups =
                    JsonConvert.DeserializeObject<List<DiscountGroupEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}discountgroups.json"));
                context.AddRange(discountGroups);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.DiscountGroup OFF");
                context.Database.CloseConnection();
            }

            if (!context.Sizes.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Size ON");
                var sizes = JsonConvert.DeserializeObject<List<SizeEntity>>(
                    File.ReadAllText($"seed{Path.DirectorySeparatorChar}sizes.json"));
                context.AddRange(sizes);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Size OFF");
                context.Database.CloseConnection();
            }

            if (!context.Customers.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Customer ON");
                var customers =
                    JsonConvert.DeserializeObject<List<CustomerEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}customers.json"));
                context.AddRange(customers);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Customer OFF");
                context.Database.CloseConnection();

            }

            if (!context.Products.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Product ON");
                var products =
                    JsonConvert.DeserializeObject<List<ProductEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}products.json"));
                context.AddRange(products);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Product OFF");
                context.Database.CloseConnection();
            }

            if (!context.PaymentTypes.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.PaymentType ON");
                var paymentTypes =
                    JsonConvert.DeserializeObject<List<PaymentTypeEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}paymenttypes.json"));
                context.AddRange(paymentTypes);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.PaymentType OFF");
                context.Database.CloseConnection();
            }

            if (!context.Sales.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Sale ON");
                var sales =
                    JsonConvert.DeserializeObject<List<SaleEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}sales.json"));
                context.AddRange(sales);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Sale OFF");
                context.Database.CloseConnection();
            }

            if (!context.SaleItem.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.SaleItem ON");
                var saleItems =
                    JsonConvert.DeserializeObject<List<SaleItemEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}saleitems.json"));
                context.AddRange(saleItems);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.SaleItem OFF");
                context.Database.CloseConnection();
            }

            if (!context.Payments.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Payment ON");
                var payments =
                    JsonConvert.DeserializeObject<List<PaymentEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}payments.json"));
                context.AddRange(payments);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Payment OFF");
                context.Database.CloseConnection();
            }
            
            if (!context.Stock.Any())
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Stock ON");
                var stockItems =
                    JsonConvert.DeserializeObject<List<StockEntity>>(
                        File.ReadAllText($"seed{Path.DirectorySeparatorChar}stocks.json"));
                context.AddRange(stockItems);
                context.SaveChanges();
                context.Database.ExecuteSqlCommand("SET IDENTITY_INSERT dbo.Stock OFF");
                context.Database.CloseConnection();
            }
        }
    }

}