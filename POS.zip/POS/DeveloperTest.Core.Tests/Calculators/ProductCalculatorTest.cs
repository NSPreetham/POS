﻿using DeveloperTest.Core.Calculators;
using Xunit;

namespace DeveloperTest.Core.Tests.Calculators
{
    public class ProductCalculatorTest
    {
        [Theory]
        [InlineData(10, 100, 90)]
        [InlineData(5, 120, 114)]
        public void Calculate_Discount_Sell_Price(decimal discountPercentage, decimal linePrice,
            decimal expectedResult)
        {
            var result = ProductCalculator.CalculateDiscountSellPrice(discountPercentage, linePrice);
            Assert.Equal(expectedResult, result);
        }
    }
}

