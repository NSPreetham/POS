﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;
using DeveloperTest.Core.Repositories;
using DeveloperTest.Core.Services;
using Moq;
using Xunit;
using System.Threading;

namespace DeveloperTest.Core.Tests.Services
{
    public class ProductServiceTest
    {
        private readonly Mock<IBrandRepository> _brandRepositoryMock;
        private readonly Mock<ISizeRepository> _sizeRepositoryMock;
        private readonly Mock<IColourRepository> _colourRepositoryMock;
        private readonly Mock<IProductRepository> _productRepositoryMock;


        private readonly IProductService _service;
        private readonly CancellationTokenSource _cancellationTokenSource;
       
        public ProductServiceTest()
        {
            _cancellationTokenSource = new CancellationTokenSource();
            _brandRepositoryMock = new Mock<IBrandRepository>();
            _colourRepositoryMock = new Mock<IColourRepository>();
            _sizeRepositoryMock = new Mock<ISizeRepository>();
            _productRepositoryMock = new Mock<IProductRepository>();
            _service = new ProductService(_brandRepositoryMock.Object, _colourRepositoryMock.Object,
                _sizeRepositoryMock.Object, _productRepositoryMock.Object);
        }

        [Fact]
        public async Task GetBrands_Returns_List_Of_Brands()
        {
            var expectedResult = new List<Brand>
            {
                new Brand {BrandId = 1, BrandName = "Nike"},
                new Brand {BrandId = 2, BrandName = "Adidas"}
            };
            _brandRepositoryMock
                .Setup(x => x.GetBrands(It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedResult);

            var brands = await _service.GetBrands(_cancellationTokenSource.Token);
            Assert.NotNull(brands);
            Assert.Equal(expectedResult, brands);
            _brandRepositoryMock.Verify(x =>
                x.GetBrands(_cancellationTokenSource.Token), Times.Once);
        }

        [Fact]
        public async Task GetColours_Returns_List_Of_Colours()
        {
            var expectedResult = new List<Colour>
            {
                new Colour {ColourId = 1, ColourName = "Red"},
                new Colour {ColourId = 2, ColourName = "Orange"}
            };
            _colourRepositoryMock
                .Setup(x => x.GetColours(It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedResult);

            var colours = await _service.GetColours(_cancellationTokenSource.Token);
            Assert.NotNull(colours);
            Assert.Equal(expectedResult, colours);
            _colourRepositoryMock.Verify(x =>
                x.GetColours(_cancellationTokenSource.Token), Times.Once);
        }

        [Fact]
        public async Task GetSizes_Returns_List_Of_Sizes()
        {
            var expectedResult = new List<Size>
            {
                new Size {SizeId = 1, SizeName = "XL"},
                new Size {SizeId = 2, SizeName = "S"}
            };
            _sizeRepositoryMock
                .Setup(x => x.GetSizes(It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedResult);

            var sizes = await _service.GetSizes(_cancellationTokenSource.Token);
            Assert.NotNull(sizes);
            Assert.Equal(expectedResult, sizes);
            _sizeRepositoryMock.Verify(x =>
                x.GetSizes(_cancellationTokenSource.Token), Times.Once);
        }

        [Fact]
        public async Task ProductSearch_Return_Search_Result()
        {
            var productSearchParameters = new ProductSearchParameters
            {
                BrandIds = new List<int> { 1 },
                SizeIds = new List<int> { 1 },
                ColourIds = new List<int> { 1 },
                SearchString = "Dri"
            };

            var expectedResult = new List<Product>
            {
                new Product
                {
                    Brand = "Nike",
                    Colour = "Red",
                    CostPrice = 27,
                    ProductId = 2,
                    ProductName = "Dri-FIT Running Vest",
                    SellPrice = (decimal) 39.99,
                    Size = "XS"
                }
            };

            _productRepositoryMock
                .Setup(x => x.ProductSearch(productSearchParameters, It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedResult);
            
            var products =
                await _service.ProductSearch(productSearchParameters, _cancellationTokenSource.Token);

            Assert.NotNull(products);
            Assert.Equal(expectedResult, products);
            _productRepositoryMock.Verify(x =>
                x.ProductSearch(productSearchParameters, _cancellationTokenSource.Token), Times.Once);
        }
    }
}
