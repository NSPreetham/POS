﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DeveloperTest.Core.Models;
using DeveloperTest.Core.Repositories;
using DeveloperTest.Core.Services;
using Moq;
using Xunit;
using System.Threading;

namespace DeveloperTest.Core.Tests.Services
{
    public class CustomerServiceTest
    {
        private readonly Mock<ICustomerRepository> _customerRepositoryMock;
        private readonly Mock<IProductRepository> _productRepositoryMock;
        private readonly ICustomerService _service;
        private readonly CancellationTokenSource _cancellationTokenSource;

        public CustomerServiceTest()
        {
            _customerRepositoryMock = new Mock<ICustomerRepository>();
            _productRepositoryMock = new Mock<IProductRepository>();
            _cancellationTokenSource = new CancellationTokenSource();
            _service = new CustomerService(_customerRepositoryMock.Object,
                _productRepositoryMock.Object);
        }

        [Fact]
        public async Task GetCustomers_Returns_List_Of_Customers()
        {
            var expectedResult = new List<Customer>
            {
                new Customer {CustomerId = 1, CustomerName = "John Smith"},
                new Customer {CustomerId = 2, CustomerName = "Peter Jones"}
            };
            _customerRepositoryMock
                .Setup(x => x.GetCustomers(It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedResult);

            var customers = await _service.GetCustomers(_cancellationTokenSource.Token);
            Assert.NotNull(customers);
            Assert.Equal(expectedResult, customers);
            _customerRepositoryMock.Verify(x =>
                x.GetCustomers(_cancellationTokenSource.Token), Times.Once);
        }

        [Fact]
        public async Task CustomerProductSearch_Return_Search_Result()
        {
            var customer = new Customer() {CustomerId = 1, CustomerName = "John Smith"};
            var productSearchParameters = new ProductSearchParameters
            {
                BrandIds = new List<int> {1},
                SizeIds = new List<int> {1},
                ColourIds = new List<int> {1},
                SearchString = "Dri"
            };

            var expectedResult = new List<Product>
            {
                new Product
                {
                    Brand = "Nike",
                    Colour = "Red",
                    CostPrice = 27,
                    ProductId = 2,
                    ProductName = "Dri-FIT Running Vest",
                    SellPrice = (decimal) 39.99,
                    Size = "XS"
                }
            };

            _productRepositoryMock
                .Setup(x => x.CustomerProductSearch(customer, productSearchParameters, It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedResult);

            _customerRepositoryMock
                .Setup(x => x.GetCustomer(It.IsAny<CancellationToken>(),1))
                .ReturnsAsync(customer);

            var products =
                await _service.CustomerProductSearch(1, productSearchParameters, _cancellationTokenSource.Token);

            Assert.NotNull(products);
            Assert.Equal(expectedResult, products);
            _productRepositoryMock.Verify(x =>
                x.CustomerProductSearch(customer, productSearchParameters, _cancellationTokenSource.Token), Times.Once);
        }
    }
}
