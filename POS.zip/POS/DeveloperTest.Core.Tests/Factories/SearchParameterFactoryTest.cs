﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using DeveloperTest.Core.Factories;
using DeveloperTest.Core.Models;
using FluentAssertions;
using Xunit;

namespace DeveloperTest.Core.Tests.Factories
{
    public class SearchParameterFactoryTest
    {
        [Fact]
        public void Populate_Product_Search_Parameters_Successfully()
        {
            string[] brandIds = {"1", "2"};
            string[] colourIds = {"3", "4"};
            string[] sizeIds = {"5", "6"};

            var expectedResult = new ProductSearchParameters
            {
                BrandIds = new List<int> {1, 2},
                SizeIds = new List<int> {5, 6},
                ColourIds = new List<int> {3, 4},
                SearchString = "dvi acc"
            };

            var result = SearchParameterFactory.CreateProductSearchParameters(brandIds, colourIds, sizeIds, "dvi acc");
            result.ShouldBeEquivalentTo(expectedResult);
        }

        [Fact]
        public void No_Parameters_Populate_Product_Search_Parameters_Successfully()
        {
            var expectedResult = new ProductSearchParameters
            {
                BrandIds = new List<int>(),
                SizeIds = new List<int>(),
                ColourIds = new List<int>(),
                SearchString = ""
            };

            var result = SearchParameterFactory.CreateProductSearchParameters(null, null, null, "");
            result.ShouldBeEquivalentTo(expectedResult);
        }
    }
}

